sphinx-build -b spelling -d _build/doctrees . _build_spelling
