.. toctree::
  :maxdepth: 2

  about_dsqss
  install
