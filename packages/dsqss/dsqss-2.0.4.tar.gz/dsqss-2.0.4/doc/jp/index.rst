.. DSQSS documentation master file, created by
   sphinx-quickstart on Mon Jun 11 16:12:51 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

DSQSS – Discrete Space Quantum Systems Solver
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Contents
--------
.. toctree::
   :maxdepth: 4
   :numbered: 4

   dsqss/index	      
   dla/tutorial/index
   dla/users-manual/index
   pmwa/tutorial/tutorial
   pmwa/tutorial/tu-index
   dsqss/algorithm

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
